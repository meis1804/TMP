from six.moves import urllib
import json


def names_and_count():

    # get request
    page = urllib.request.urlopen('https://hub.docker.com/v2/repositories/nm10pt').read()
    page = page.decode()

    # str to dict
    res = json.loads(page)

    return get_names(res), count(res)  # list, int


def get_names(res):
    images = res['results']
    tools = []
    for i in images:
        tools.append(i["name"])
    return tools


def count(res):
    count_images = res['count']
    return count_images

