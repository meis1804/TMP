import subprocess
import os


def execute_shell(command):
    check_newpwd(command)
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, encoding='utf-8', universal_newlines=True)
    out = '<br>'.join(p.stdout.readlines())
    return out, os.getcwd()


def check_newpwd(command):
    if command[0:3] == "cd ":
        os.chdir(command[3:])

